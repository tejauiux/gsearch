import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { SearchService } from './search.service';

import { LandingSearchComponent } from './landing-page-search.component';

@NgModule({
  declarations: [
    LandingSearchComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
  ],
  providers: [SearchService],
  bootstrap: [LandingSearchComponent]
})
export class LandingPageSearchModule {}

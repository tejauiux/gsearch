import { Component } from '@angular/core';
import { SearchService } from './search.service';

import { ISearchResult } from './searchresult';

@Component({
    selector: 'landingsearch',
    templateUrl: 'landingsearch-filter.html'
})

export class LandingSearchComponent {
    constructor(private searchService: SearchService){}

    public filterKey = '';
    public filteredItems = [];
    public ObjectItems = [];
    public errorMessage = '';


    filter(): void {
    if(this.filterKey!==""){
        this.searchService.searchApplications(this.filterKey)
            .subscribe(data=> {
                //this.ObjectItems = data || [];
                if(data){
                    for(var i in data){
                        if(i=="items"){
                            for(var l in data[i]){
                                this.ObjectItems.push(data[i][l]["title"]);
                                //console.log(this.ObjectItems[i][l])
                            }
                        }
                    }
                }
                
                this.filteredItems = this.ObjectItems;
                /*if(d!==""){
                    for(var i in d){
                        console.log(i, d.items);
                    }
                    this.filteredItems = d;
                }else{
                    this.filteredItems = [];
                }*/
                
            },
            error => {
                this.errorMessage = <any>error
            });
    }

    else{
        this.filteredItems = [];
    }
}

select(item): void {
    this.filterKey = item;
    this.filteredItems = [];
}
}

export interface ISearchResult {
    title: string,
    totalResults: long,
    language: string;
}
